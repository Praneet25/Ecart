from django.contrib import admin

# Register your models here.
from .models import Blogpost,User

admin.site.register(Blogpost)
admin.site.register(User)
