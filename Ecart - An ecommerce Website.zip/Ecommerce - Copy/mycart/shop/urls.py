from . import views
from django.urls import path

urlpatterns = [
    path('', views.index , name ='homeshop'),
    path('about/', views.about, name ='Aboutus'),
    path('contactus/', views.contactus , name ='contactus'),
    path('tracker/', views.tracker , name ='Trackingstatus'),
    path('search/', views.search , name ='search'),
    path('prodview/<int:myid>', views.prodview , name ='productview'),
    path('checkout/', views.checkout , name ='checkout'),
]
