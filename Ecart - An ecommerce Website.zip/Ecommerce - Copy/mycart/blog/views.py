from django.shortcuts import render
from django.http import HttpResponse
from .models import Blogpost,User

# Create your views here.

def index(requests):
    allposts=[]
    posts = Blogpost.objects.all()
    for post in posts:
        allposts.append(post)
    params = {'post':allposts}

    return render(requests,'blog/index.html',params)


def blogpost(requests,id):
    post = Blogpost.objects.filter(post_id=id)[0]
    params = {'post':post}
    return render(requests,'blog/blogpost.html',params)
#
def verifydetails(username,name,email,password,cpassword):
    if password != cpassword:
        return False
    elif username=="" or name=="" or email=="" or password=="" or cpassword == "":
        return False
    else:
        return True

def signup(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        name = request.POST.get('name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        cpassword = request.POST.get('cpassword')
        vw = verifydetails(username,name,email,password,cpassword)
        if vw:
            user = User(name=name, username=username, password=password, email=email)
            user.save()
            thank = 'Your profile has been created successfully'
            return render(request, 'blog/signup.html', {'thank': thank})
    # thank = 'Kindly check he details and type again'
    return render(request, 'blog/signup.html')