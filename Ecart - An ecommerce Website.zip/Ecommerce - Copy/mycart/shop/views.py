from django.shortcuts import render
from django.http import HttpResponse
from .models import Product,Contact,Order,OrderUpdate
from math import ceil
import json

# Create your views here.

def index(request):

    allProds =[]
    prodcat =Product.objects.values('product_category','id')
    cats = {item['product_category'] for item in prodcat}
    for cat in cats:
        product = Product.objects.all()
        #we use prod to filter products according to their category
        prod = Product.objects.filter(product_category=cat)
        n=len(product)
        nSlides = n // 4 + ceil((n / 4) - (n // 4))
        #these filtered products are stored in in ampty list along with othere params
        allProds.append([prod,range(1,nSlides),nSlides])

    params = {'allProds':allProds}
    return render(request,'shop/index.html',params)

def searchmatch(query,item):
    if query in item.product_desc.lower() or query in item.product_name.lower() or query in item.product_category.lower():
        return True
    else:
        return False

def search(request):
    query = request.GET.get('search').lower()
    allProds = []
    prodcat = Product.objects.values('product_category', 'id')
    cats = {item['product_category'] for item in prodcat}
    for cat in cats:
        product = Product.objects.all()
        # we use prod to filter products according to their category
        prodtem = Product.objects.filter(product_category=cat)
        prod = [item for item in prodtem if searchmatch(query,item)]
        n = len(product)
        nSlides = n // 4 + ceil((n / 4) - (n // 4))
        if len(prod) != 0 :
        # these filtered products are stored in in ampty list along with othere params
            allProds.append([prod, range(1, nSlides), nSlides])

    params = {'allProds': allProds,'msg':''}

    if len(allProds)==0 or len(query) < 4:
        params = {'msg':"Please enter relevant details in the search box"}

    return render(request, 'shop/search.html', params)


def about(request):
    return render(request,'shop/about.html')

def contactus(request):
    if request.method == 'POST':
        name = request.POST.get('name','')
        email=request.POST.get('email','')
        phone=request.POST.get('phone','')
        query=request.POST.get('query','')
        contact = Contact(name=name,phone=phone,email=email,query=query)
        contact.save()
        thank = True
        return render(request,'shop/contactus.html',{'thank':thank})


    return render(request,'shop/contactus.html')

def tracker(request):
    if request.method=="POST":
        orderId = request.POST.get('orderId', '')
        email = request.POST.get('email', '')
        try:
            order = Order.objects.filter(order_id=orderId, email=email)
            print(order)
            print(len(order))
            if len(order)>0:
                update = OrderUpdate.objects.filter(order_id=orderId)
                updates = []
                for item in update:
                    updates.append({'text': item.update_desc, 'time': item.timestamp})
                    response = json.dumps([updates, order[0].json_item], default=str)
                return HttpResponse(response)
            else:
                return HttpResponse('{}')
        except Exception as e:
            return HttpResponse('{}')

    return render(request, 'shop/tracker.html')



def checkout(request):
    if request.method == 'POST':
        json_item = request.POST.get('json_item','')
        name = request.POST.get('name','')
        email=request.POST.get('email','')
        address=request.POST.get('address1','') + request.POST.get('address2','')
        phone=request.POST.get('phone','')
        city=request.POST.get('city','')
        state=request.POST.get('state','')
        zip_code=request.POST.get('zip_code','')
        order = Order(json_item=json_item,name=name,phone=phone,address=address,city=city,state=state,zip_code=zip_code,email=email)
        order.save()
        update = OrderUpdate(order_id=order.order_id, update_desc='Your order has been placed')
        update.save()
        thank = True
        id = order.order_id

        return render(request,'shop/checkout.html',{'thank':thank,'id':id})

    return render(request,'shop/checkout.html')

def prodview(request,myid):
    product = Product.objects.filter(id=myid)
    return render(request,'shop/prodview.html',{'product':product[0]})